# Course description plugin
=======================
* Plugin type:    Ressource
* Moodle Version: 2.8
* Maintained by:  Flotter Totte
* Copyright:      emeneo


The course description plugin is a ressource which displays the course name and the course description on the course page (at the location where it is placed). It is a small but handy tool.

Installation
============
Unzip the package and put the folder 'description' into /mod/ of your moodle intsall


Requirements
------------
Moodle 2.8
(it should also work with moodle 2.0-2.7 but this has not been tested so far)


Roadmap
=======
1. Add further information
2. Make information display conditional








